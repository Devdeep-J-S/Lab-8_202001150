package lab8_test;

public class P1 {

}
