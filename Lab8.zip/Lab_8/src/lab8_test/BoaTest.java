package lab8_test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BoaTest {

	static Boa Mitsuha , Taki;  // Your name .
	@Before
	public void setUp() throws Exception {
			Mitsuha = new Boa("Mitsuha",5,"granola bars") ;
			Taki = new Boa("Taki",6,"Ramen");
		}

	@Test
	public void testIsHealthy() {
		assertTrue(Mitsuha.isHealthy());
		assertFalse(Taki.isHealthy());
	}
	
	@Test
	public void testFitsInCage()
	{
		assertTrue(Mitsuha.fitsInCage(6));
		assertFalse(Taki.fitsInCage(6));
	}
	
	@Test 
	public void testlengthInInches(){
		int len = Mitsuha.lengthInInches() ; 
		assertEquals(60,len);
	}
	
	@After
	public void last_func()
	{
		Mitsuha =null ;
		Taki = null ; 
		System.out.println("Thank you for this lab!!!");
	}

}
